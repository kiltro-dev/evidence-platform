Atlas Live M5 evidence bundle
=============================

Exported: 2026-11-02T02:46:00+00:00
Claims: 31  Packages: 22  Snapshots: 16

Contents
--------
run.jsonl        bus event log (verbatim copy of the run)
snapshots/       immutable source snapshots (content-addressed)
packages.json    evidence packages (M2a EvidencePackage dicts)
claims.json      claim inputs + recorded verdicts (verifier re-run needs these)
truth_ref.json   keynote truth rows (judge reference)
verify_bundle.py standalone offline re-verifier (no network, no model)
README.txt       this file
manifest.json    sha256 of every file above (verify_bundle.py excluded:
                 it verifies the rest; re-hash it against the repo when needed)

How to verify
-------------
  python verify_bundle.py bundle.zip
  python verify_bundle.py bundle.zip --engine stdlib   # without the repo
  python verify_bundle.py ./extracted_dir/

PASS/FAIL is printed per claim; exit code is 0 iff every claim passes.
Engines: "live.verifier" (the real live/verifier/check.py, needs the repo
on PYTHONPATH) or "stdlib-mirror" (vendored in verify_bundle.py).
